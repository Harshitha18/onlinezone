package com.niit.skillmapengine.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.niit.skillmapengine.configuration.DbConfig;
import com.niit.skillmapengine.model.Skills;

public class SkillsDaoImpl implements SkillDao {

	Connection conn;
	
	
	public SkillsDaoImpl() 
	{
		super();
		this.conn = DbConfig.getConnection();
	}

	@Override
	public boolean saveSkill(Skills skill) 
	{
		try
		{
		Statement st=conn.createStatement();
		String str="INSERT INTO `skillmapengine`.`skills` (`SKILLS`) VALUES ('"+skill.getSkill()+"')";
		int rs=st.executeUpdate(str);
		
		return true;
		}
		catch(Exception ex)
		{
			System.out.println("Exception Occured :"+ex.getMessage());
			return false;
			
		}
		finally
		{		
			try 
			{

				conn.close();
			}
			catch (SQLException e1) 
			{
				e1.printStackTrace();
			}
		 }
	}

	@Override
	public boolean deleteSkill(Skills skill) 
	{
		try
		{
		Statement st=conn.createStatement();
		String str="DELETE FROM `skillmapengine`.`skills` WHERE `skills`.`SID` = "+skill.getId();
		int rs=st.executeUpdate(str);
		
		return true;
		}
		catch(Exception ex)
		{
			System.out.println("Exception Occured :"+ex.getMessage());
			return false;
			
		}
		finally
		{		
			try 
			{

				conn.close();
			}
			catch (SQLException e1) 
			{
				e1.printStackTrace();
			}
		 }
	}

	@Override
	public boolean updateSkill(Skills skill)
	{
		try
		{
		Statement st=conn.createStatement();
		String str="UPDATE  `skillmapengine`.`skills` SET  `SKILLS` =  '"+skill.getSkill()+"' WHERE  `skills`.`SID` ="+skill.getId();
		int rs=st.executeUpdate(str);
		
		return true;
		}
		catch(Exception ex)
		{
			System.out.println("Exception Occured :"+ex.getMessage());
			return false;
			
		}
		finally
		{		
			try 
			{

				conn.close();
			}
			catch (SQLException e1) 
			{
				e1.printStackTrace();
			}
		 }
	}

	@Override
	public List<Skills> getSkillList() 
	{
		List<Skills> skills=new ArrayList();
		Skills s;
		try
		{
		Statement st=conn.createStatement();
		String str="SELECT * FROM  `skills`";
		ResultSet rs=st.executeQuery(str);
		while(rs.next())
		{
			s=new Skills();
			s.setId(rs.getInt("SID"));
			s.setSkill(rs.getString("SKILLS"));
			skills.add(s);
		}
		
		return skills;
		}
		catch(Exception ex)
		{
			System.out.println("Exception Occured :"+ex.getMessage());
			return skills;
			
		}
		finally
		{		
			try 
			{
				conn.close();
			}
			catch (SQLException e1) 
			{
				e1.printStackTrace();
			}
		 }
		
	}

}
