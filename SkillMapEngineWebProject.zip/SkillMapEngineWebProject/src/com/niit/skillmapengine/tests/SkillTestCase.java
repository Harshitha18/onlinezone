package com.niit.skillmapengine.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.niit.skillmapengine.dao.SkillDao;
import com.niit.skillmapengine.dao.SkillsDaoImpl;
import com.niit.skillmapengine.model.Skills;

public class SkillTestCase 
{
	SkillDao skilldao;
	

	@Before
	public void setUp() throws Exception 
	{
		skilldao=new SkillsDaoImpl();
	}

	@Test
	public void save() {
		Skills s=new Skills();
		s.setSkill("CPP");
	
		assertTrue("Save Failed",skilldao.saveSkill(s));
		
	}
	
	@Test
	public void getAll()
	{
		System.out.println("\nSKILLS\n========\n"+skilldao.getSkillList());
	}
	
	@Test
	public void update() {
		
		Skills s=new Skills();
		s.setId(8);
		s.setSkill("HTML");
	
		assertTrue("Updation Failed",skilldao.updateSkill(s));
	}
	
	@Test
	public void delete() {
		Skills s=new Skills();
		s.setId(9);
	
		assertTrue("delete Failed",skilldao.deleteSkill(s));
	}

}
