package com.niit.skillmapengine.exceptions;

public class ValidationException extends Exception
{
	public ValidationException(String msg)
	{
		super(msg);
	}

}
