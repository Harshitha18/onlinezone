package com.niit.skillmapengine.model;

public class Skills 
{
	int id;
	String skill;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	@Override
	public String toString() {
		return "Skills [id=" + id + ", skill=" + skill + "]";
	}
	
	
	

}
